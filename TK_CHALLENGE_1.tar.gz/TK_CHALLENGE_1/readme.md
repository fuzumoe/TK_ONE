 #  STPES TO RUN THE APPLICATION
|======================================================================================|
#@ N.B you can see the creen shots also 
|--------------------------------------------------------------------------------------|
   1# open three terminal windows 
|--------------------------------------------------------------------------------------|
   2# In one of the terminals  type the following commands sequntialy
       1- cd MinionGameServer/
       2- ant run 
|--------------------------------------------------------------------------------------|
   3# In the remaining two terminal windows run the following commands one after the other
     #In the remaining firs window
       1- cd MinionGameClient/
       2- ant run 
   ______________________________________________________________________ 
      #In the remaining second window
       1- cd MinionGameClient/
       2- ant run 
    __________________________________________________________________________ 
|--------------------------------------------------------------------------------------|
|======================================================================================|
